#About
Previously here was a fork of canvg. But for compatibility and testing opportunity we keep here a copy of canvg.

#Usage
For examples converting HTML pages and SVG elements into PDF using canvg and the context2d plugin,
see the examples in the /examples/canvg_context2d directory.
